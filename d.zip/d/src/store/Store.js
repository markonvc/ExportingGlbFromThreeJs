class Store {
  scene = null;
  modelHref = null;
  renderer = null;
}

export default new Store();
