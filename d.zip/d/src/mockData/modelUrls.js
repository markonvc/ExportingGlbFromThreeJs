export default {
  twoSeat: {
    modelUrl:
      "models/twoSeat.glb",
  },
  armChair: {
    modelUrl: "models/armChair.glb",
  },
};
